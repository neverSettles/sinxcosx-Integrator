//Christopher Settles
#include <iostream>
#include <iomanip>
#include <string>
#include "TrigArray.h"
using namespace std;

//TrigArray::TrigArray() {}


string TrigArray::toString()
{
	return string();
}

void TrigArray::simplify()
{
	//for (int i = 0; i < sizeOfArray(TrigTermArray); i++)
	{

	}
}
