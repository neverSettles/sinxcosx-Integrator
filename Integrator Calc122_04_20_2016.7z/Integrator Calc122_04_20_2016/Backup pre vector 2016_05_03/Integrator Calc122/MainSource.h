#pragma once
//Christopher Settles Calc122 Integrator Project
#include <iostream>
#include <iomanip>
#include <string>
#include "TrigTerm.h"
using namespace std;
class MainSource {
private:

public:
	int main();
};