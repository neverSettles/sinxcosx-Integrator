#pragma once
//Christopher Settles
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

//Other usefull functions
int fact(int i);
int nCr(int exp, int place);